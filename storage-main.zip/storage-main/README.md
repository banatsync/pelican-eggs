# Storage

## S3 Storage

* [minio](/minio)

## SFTP Storage Share ("Empty Egg")

* [SFTP Storage Share](/sftp_storage_share)
