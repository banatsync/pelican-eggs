# PostgreSQL

## From their [Website](https://www.postgresql.org/)

The World's Most Advanced Open Source Relational Database

## Minimum RAM warning

2 Gigabytes minimum recommended

See here <https://www.commandprompt.com/blog/postgresql_mininum_requirements/>

## Server Ports

Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Server  |  5432   |
