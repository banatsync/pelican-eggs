# Generic Language

### [C#](c%23)

[C#](https://learn.microsoft.com/en-us/dotnet/csharp//)
A generic C# language egg running with dotnet

### [Elixir](elixir)

[elixir](https://elixir-lang.org/)
A generic Elixir language egg

### [Dart](dart)

[dart](https://dart.dev/)
A generic Dart language egg

### [Deno](deno)

[deno](https://deno.land/)
A generic Deno language egg

### [Golang](golang)

[golang](https://go.dev/)
A generic Go language egg

### [Java](java)

[java](https://www.java.com/en/)
A generic Java (and Kotlin) language egg

### [Lua](lua)

[lua](https://www.lua.org/)
A generic Lua (Luvit) language egg

### [Node JS](nodejs)

[nodejs](https://nodejs.org)
A generic Node.JS egg

### [Bun](bun)

[bun](https://bun.sh)
A generic Bun egg

### [nodemon](nodemon)

[nodemon](https://nodemon.io/)
A nodemon JavaScript and TypeScript language egg for running and automatically restarting the node application when file changes in the directory are detected

### [Python](python)

[python](https://www.python.org/)
A generic Python language egg

### [Rust](rust)

[rust](https://www.rust-lang.org/)
A generic Rust language egg
