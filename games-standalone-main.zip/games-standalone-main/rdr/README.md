# Read Dead Redemption

## RedM

[RedM](https://redm.gg/)
RedM, for Red Dead Redemption 2 on PC. Launching now, based on the CitizenFX framework and Cfx.re technology.
