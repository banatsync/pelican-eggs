# The Battle for Wesnoth

## From their [Github](https://github.com/wesnoth/wesnoth)

## [Documentation](https://github.com/wesnoth/wesnoth/blob/master/INSTALL.md)

The Battle for Wesnoth is an Open Source, turn-based tactical strategy game with a high fantasy theme, featuring both singleplayer and online/hotseat multiplayer combat. Fight a desperate battle to reclaim the throne of Wesnoth, search for the key to immortality, or take part in any number of other adventures.

## Install notes

Takes a while to install first time due to a ton of extra packages packages and the source code being installed/downloaded.
