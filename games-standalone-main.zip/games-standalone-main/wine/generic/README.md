# Wine Generic

A generic wine image that can be used to install servers that need wine to run.
Downloads compressed server files and extracts them to a specified folder in `/mnt/server/`

I.E. `INSTALL_DIR` = `server/folder` will unpack the server into `/mnt/server//server/folder/`

## Install notes

May require a full custom start command. This is on you to figure out what that is.
