# AssaultCube
[assault.cubers.net](https://assault.cubers.net/)

AssaultCube is a FREE, multiplayer, first-person shooter game, based on the CUBE engine.

Taking place in realistic environments, with fast, arcade gameplay, it's addictive and fun!

With efficient bandwidth usage, it's low-latency and can even run over a 56 Kbps connection.
It's tiny too, weighing in at a lightweight about 50 MB package available for Windows, Mac and Linux.
On the correct settings, it can even run on old hardware (Pentium III and above).

---

## Server Ports

Ports required to run the server.

| Port    | default |
|---------|---------|
| Game    | 28763   |
| Game +1 | 28764   |

The second port is only used for the server master list to be able to update the server info. (Description, player count, etc.)

**Must be Game +1!**

### Notes

<!--Notes about the server ports.-->
28763 & 28764 is the default ports, but any port can be used.
