# Clone Hero 

## From their [Site](https://clonehero.net/)

## [Documentation](https://wiki.clonehero.net/books/guides-and-tutorials/page/online-multiplayer#bkmrk-hosting-a-standalone)


## Minimum RAM warning

Minimum required memory to run the server.
80MiB is recommended. 2GB+ is preferred

## Minumim Sorage warning

Minimum required storage to run the server.
100MiB is recommended. 2GiB+ is preferred


## Server Ports

Ports required to run the server.

| Port    | default |
|---------|---------|
| Game    | 14242   |

### Notes

<!--Notes about the server ports.-->
14242 is the default port, but any port can be used.

