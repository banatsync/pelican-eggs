# HogWarp

HogWarp is a Work In Progress mod that adds Multiplayer functionality to Hogwarts Legacy, similar to FiveM for GTAV

This Mod requires a API key only obtainable through their Discord, see the Startup Variable **API KEY** for more info.
- Some features of the mod (Public servers / higher player counts) require a Patreon level. See their Patreon here: https://www.patreon.com/tiltedphoques

# Important Info
The Server files are *exclusivily* in their Discord, to install you can either manually upload the Zip and unarchive after server creation; or upload the data to your own source and update the *DOWNLOAD_URL* variable

## Server Port
| Port    | default |
|---------|---------|
| Game    | 11778   |

## Hardware Requirements
| Storage | RAM     | CPU |
|---------|---------|-----|
| 1.5GiB  | 250MiB  | 🥔  |

