# Nazi Zombies: Portable (NZ:P)

Nazi Zombies: Portable is a project that allows you to play Call of Duty: Zombies on a LOT of devices/platforms, from Windows to Linux to Browser to Nintendo Switch to PSP to PlayStation VITA (you get the idea).
It is based on the FTEQW engine and this egg can be used as a plain FTEQW egg if you desire.

## Server Ports

| Port                          | default |
|-------------------------------|---------|
| Game WS/TCP (for Web Clients) |  27500  |
| Game UDP (for Native Clients) |  27500  |

### Notes

Resources pertaining to NZ:P Native Client download, browser release and documentation.

* [NZ:P Native](https://github.com/nzp-team/nzportable/releases)
* [NZ:P Browser](https://nzp.gay)
* [NZ:P Documentation](https://docs.nzp.gay)
