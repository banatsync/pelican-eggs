# Rimworld Together

## From their [site](https://rimworld-together.fandom.com/wiki/Rimworld_Together_Wiki)

## From their [Github](https://github.com/Byte-Nova/Rimworld-Together)

A community driven multiplayer mod, for Rimworld.

[Rimworld Together](https://steamcommunity.com/sharedfiles/filedetails/?id=3005289691)

## Server Ports

| Port    | default |
|---------|---------|
| Game    | 25555   |

