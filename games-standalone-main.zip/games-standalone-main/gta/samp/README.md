# SA:MP

The [SA:MP](https://www.sa-mp.mp/) GTA San Andreas dedicated server
