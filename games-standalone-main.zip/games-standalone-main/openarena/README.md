# OpenArena

## From their [site](http://www.openarena.ws)

OpenArena is a community-produced deathmatch FPS based on GPL idTech3 technology.

There are many game types supported including Free For All, Capture The Flag, Domination, Overload, Harvester, and more.

## Server Ports

| Port    | default |
|---------|---------|
| Game    | 27960   |

### Mods/Plugins may require ports to be added to the server
