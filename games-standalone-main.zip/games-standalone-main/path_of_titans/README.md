# Path Of Titans

## Install notes
This could be a little buggy or not well tested because made on the fast hand.

You need to open these ports before running the server `7777, 7778, 7779, 7780, 7781`. They are require for RCON, seeing your servr on the list and etc.

# Other documentation

If you are experienced the I could reccomend using this documentation website on the github
[DOCS](https://github.com/Alderon-Games/pot-community-servers/wiki)

Get the AUTH token at https://alderongames.com/oauth/hosting-token.
p.s. YOU NEED TO OWN the game

## Server Ports

Ports required to run the server in a table format.

| Port          | default |
|---------------|---------|
| Game          | 7777    |
| Reserved port | 7778    |
| Rcon          | 7779    |
| Stats         | 7780    |
| Query         | 7781    |

### Notes

`7777` is the default port, but any port can be used.
You need to assign to network port `7779` if you want to use RCON
Also you need to open port `7778` and `7781` for the query, so it can appear on the server list.
`7780` is Stats port.

`7777, 7781` open for UDP
`7778, 7779, 7780` both protocols


