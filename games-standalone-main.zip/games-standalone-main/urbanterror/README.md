# Urban Terror

## From their [Website](https://www.urbanterror.info/downloads/)

Urban Terror™ is a free multiplayer first person shooter developed by FrozenSand, that will run on any Quake III Arena compatible engine. It is available for Windows, Linux and Macintosh.

Urban Terror can be described as a Hollywood tactical shooter; somewhat realism based, but the motto is "fun over realism". This results in a very unique, enjoyable and addictive game.

## Installation/System Requirements
|  | Bare Minimum | Recommended |
|---------|---------|---------|
| Processor | Almost any proccessor will work | - |
| RAM | 256 MiB | 512 MiB |
| SWAP| 512 MiB | 512 MiB (Swap not needed if RAM is 1024MiB)|
| Storage | 1500 MiB | 2000 MiB |
| Network | Any reasonable speed |- |
| Game Ownership | Not needed | The game is free, and server doesn't need the game to work. |   

## Server Ports

| Port    | default |
|---------|---------|
| Game    | 27960   |


## Game Infos
Gamemodes: 0 = Free For All, 1 = Last Man Standing, 3 = Team DeathMatch, 4 = Team Survivor, 5 = Follow The Leader, 6 = Capture And Hold, 7 = Capture The Flag, 8 = Bomb Mode, 9 = Jump, 10 = Freeze Tag, 11 = Gun Game
You can edit the Server.cfg in /home/container/q3ut4/server.cfg as you wish after creating the server. 
