# PhantomBot

[Website](https://phantombot.dev/)
[GitHub](https://github.com/phantombot/PhantomBot)
PhantomBot is an actively developed open source interactive Twitch bot with a vibrant community that provides entertainment and moderation for your channel, allowing you to focus on what matters the most to you - your game and your viewers.

## Server Ports

1 port is required to run PhantomBot.

| Port                | default |
|---------------------|---------|
| Web UI (HTTP Server)| 25000   |
