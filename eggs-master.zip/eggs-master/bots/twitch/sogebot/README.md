# SogeBot

[Website](https://sogebot.xyz)
[GitHub](https://github.com/sogebot/sogeBot)
Free Twitch Bot built on Node.js

## Server Ports

1 port is required to run sogeBot.

| Port                | default |
|---------------------|---------|
| Game (HTTP Server)  | 20000   |

## NOTES

The installation take a long time, because a lot of things must be compiled. It can take 5 or more minutes !!!
