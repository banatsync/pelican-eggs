# Twitch Bots

## Some of these bots support other services but are primarily Twitch bots

### [PhantomBot](phantombot)

[Website](https://phantombot.github.io/PhantomBot/)
[GitHub](https://github.com/phantombot/PhantomBot)
PhantomBot is an actively developed open source interactive Twitch bot with a vibrant community that provides entertainment and moderation for your channel, allowing you to focus on what matters the most to you - your game and your viewers.

### [SogeBot](sogebot)

[Website](https://sogebot.xyz)
[GitHub](https://github.com/sogebot/sogeBot)
Free Twitch Bot built on Node.js
