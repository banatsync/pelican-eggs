# Dynamica

## Their [Github](https://github.com/dynamicabot/dynamica-v2)

An easy-to-use dynamic voice channel bot.

## Port
You will manual have to change the web port in the src/main.ts on line 24.