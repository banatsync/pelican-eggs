# pixelbot

## Their [Github](https://github.com/possatti/pixelbot)

Bot for pixelcanvas.io

## Server Ports

There are no ports required for pixelbot

## Side notes

This was to make sure the parkervcp/images:python 3 image worked.
