# CorpBot.py

## From their [Github](https://github.com/corpnewt/CorpBot.py)

A very clumsy python bot for discord

## Server Ports

No ports are required to run CorpBot. You can assign a random port to the bot.

### Mods/Plugins may require ports to be added to the server
