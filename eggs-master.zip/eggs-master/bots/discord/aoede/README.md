# Aoede

### Authors / Contributors
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
    <tr>
        <td align="center">
            <a href="https://github.com/cleme29">
                <img src="https://avatars.githubusercontent.com/u/8092733" width="50px;" alt=""/><br /><sub><b>cleme29</b></sub>
            </a>
            <br />
            <a href="https://github.com/parkervcp/eggs/commits?author=cleme29" title="Codes">💻</a>
            <a href="https://github.com/parkervcp/eggs/commits?author=cleme29" title="Maintains">🔨</a>
        </td>       
    </tr>
</table>
<!-- markdownlint-enable -->
<!-- prettier-ignore-end -->
Special thanks to Red-Thirten for providing most of the installation script and to TubaApollo & QuintenQVD0 for the Muse egg that helped build most of this one !

## Their [Github](https://github.com/codetheweb/aoede)

Aoede is a Discord music bot that directly streams from Spotify to Discord. The only interface is Spotify itself.

## Server Ports

There are no ports required for the Aoede bot
