# SinusBot

## Their [Site](https://www.sinusbot.com/)

Listen to your favorite music together with all of your friends

Welcome the Simple, Elegant & great sounding TS3- and Discord-Bot!

## First startup

On first startup wait until this message in the console appears: `TSClient quit.` Then press restart. 
Now the SinusBot will fully startup and you can login to the WebUI.

## Server Ports

1 port is required to run SinusBot.

| Port    | default |
|---------|---------|
| Game    | 8087    |

## Side notes

This uses a custom image.
