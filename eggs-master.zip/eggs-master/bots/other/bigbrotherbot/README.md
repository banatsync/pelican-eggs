# Big Brother Bot

## From their [Github](https://github.com/BigBrotherBot/big-brother-bot)

Big Brother Bot B3 is a complete and total server administration package for online games. B3 is designed primarily to keep your server free from the derelicts of online gaming, but offers more, much more

## Server Ports

No ports are required to run Big Brother Bot. You can assign a random port to the bot.

### Mods/Plugins may require ports to be added to the server
