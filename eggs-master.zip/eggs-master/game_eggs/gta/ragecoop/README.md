# ragecoop.online

The [ragecoop](https://ragecoop.online/) Drive around the interstate with your buddy, enjoy GTAs environment, make own missions and events or just chill in Grove Street! 🌐

## Server Ports

ragecoop requires one port for both UDP/TCP

| Port    | default  |
|---------|----------|
| Game    | 4499    |
