# OpenMp

The [OpenMp](https://www.open.mp/) GTA San Andreas dedicated server

## Server Ports


| Port    | default |
|---------|---------|
| Game    | 25570   |
