# No Love Lost

Grab your ragtag crew & take up the Nectar Raiding trade on a dangerous planet that’s become all the rage! 
In this PvPvE extraction game for 1-10 players, compete against enemy crews to harvest as much Nectar as possible before night falls. 
But watch out, you're not the only one roaming this planet!

## Server Port
| Port    | default |
|---------|---------|
| Game    | 7777    |
| Query   | 27015   |

## Hardware Requirements
| Storage | RAM     |
|---------|---------|
| 6.0GB   | 6.0GB   |