# Black Mesa

## From their [Website](https://www.crowbarcollective.com/games/black-mesa)

Black Mesa is a 2020 first-person shooter game. It is a third-party remake of Half-Life (1998) made in the Source game engine.

## Server Ports

BlackMessa servers require 2 ports to be open, the SourceTV port can also be opened for spectators.

| Port      | default |
|-----------|---------|
| Game/rcon | 27015   |
| SourceTV  | 27020   |
| ClientPort  | 27005   |

## Steam Download [SteamStore](https://store.steampowered.com/app/362890/Black_Mesa/)
