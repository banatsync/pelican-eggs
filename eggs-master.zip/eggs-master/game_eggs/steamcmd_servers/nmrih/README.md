# No More Room in Hell

## From their [Website](https://www.nomoreroominhell.com/)

No More Room in Hell is the ultimate ruthless and unforgiving co-operative zombie survival experience on the Source Engine, delivering award winning survival horror gameplay with dozens of weapons and multiple game modes.

## Server Ports

NMRIH servers require 1 port to be open, the SourceTV port can also be opened for spectators.

| Port      | default |
|-----------|---------|
| Game/rcon | 27015   |
| SourceTV  | 27020   |

## Steam Download [SteamStore](https://store.steampowered.com/app/224260/No_More_Room_in_Hell/)
