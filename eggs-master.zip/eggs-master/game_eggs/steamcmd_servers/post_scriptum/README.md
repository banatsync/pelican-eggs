# Post Scriptum

Post Scriptum is a WW2-themed first-person tactical shooter that provides an authentic WWII combat experience. Focusing on historical accuracy, large-scale battles, and a challenging battlefield demands an intense need for cohesion, communication, and teamwork.

## Server Ports

Post Scriptum requires Game and Query port to function, while RCON port is only required if you want to use RCON.

| Port            | default |
|-----------------|---------|
| Game            | 10027   |
| Query           | 10037   |
| RCON (optional) | 21114   |
