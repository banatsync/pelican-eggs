# Subnautica: Nitrox Mod

Subnautica is an open world survival action-adventure video game developed and published by Unknown Worlds Entertainment.
In it, players are free to explore the ocean on an alien planet, known as planet 4546B, after their spaceship, the Aurora, crashes on the planet's surface.
The multiplayer function is provided by the mod "Nitrox". This mod is still in alpha version and therefore not yet fully stable.

## NOTE

To download the base game, you will need to authenticate against Steam.
Because of the normally active Steamgaurd protection, it is important to enter the Steamgaurd code.
Once the initial installation is complete, you will need to enter the Steamguard code that will be emailed to you and then reinstall the server.

This will only work if you receive Steamguard codes via mail. The Authenticator app is not supported.

## NOTE 2

NitroxMod version >=1.5.0.0 is required for this egg

## Server Ports

The nitrox server requires only the default Server port.

| Port   | default |
|--------|---------|
| Server |   any   |
