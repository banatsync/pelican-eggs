# The Isle Evrima

The Isle is an open beta with an open-world survival game where players choose from three factions in an attempt to survive a fierce island. Hunt. Prey. Survive.

### Server Ports
The Isle requires 3 ports

| Port  | default |
|-------|---------|
| Game  | 7777    |
| Rcon  | 9999    |
| Queue | 10000   |
