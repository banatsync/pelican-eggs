# Swords 'n Magic and Stuff

Grab your friends and set out for adventure in a world of swords, magic, and stuff. Discover tons of cool loot, uncover hidden secrets, and meet new friends and foes along the way. Make your mark and find a place to call home in this cute, multiplayer, open world RPG. 

## Console
Because there is not yet a real console this egg uses a wrapper that prints the log file to the console but it is a continue loop so it will keep sending the contents of the latest log file to the console. The console does not accept any input. 

There is a 30 seconds timeout before the wrapper will try to start the server as it needs to wait until the log file is written and the first lines are writen to that file.

## first start
Because of the wrapper the first start of the console will show no logs. On first start wait for vcrun2019 to install. Then hit restart.

## Server Ports


| Port      | default |
|-----------|---------|
| Game      | 7777    |
| Query     | 27015   |


