# TerraTech Worlds

Steam Description :
TerraTech Worlds is an open-world, PvE survival game set on an uncharted alien planet. Explore, mine, build, craft and battle your way through natural hazards and dangerous enemies, to harness the power of your environment. Play solo or up to 6 friends via online co-op, and get ready for adventure!

---
## Server Ports

Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 7777    |

## Known Issues

1) Proxmox VM(s): You'll need to change your Processor Type to `Host` (Default: kvm64)
