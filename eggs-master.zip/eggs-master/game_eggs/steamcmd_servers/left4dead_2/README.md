# Left 4 Dead 2

## From their [Website](https://www.l4d.com/)

Set in the zombie apocalypse, Left 4 Dead 2 (L4D2) is the highly anticipated sequel to the award-winning Left 4 Dead, the #1 co-op game of 2008.

### Server Ports

L4D 2 servers require 1 port to be open. The port can be safely changed to any other.

| Port      | default |
|-----------|---------|
| Game/rcon | 27015   |

## Steam Download [SteamStore](https://store.steampowered.com/app/550/Left_4_Dead_2/)

