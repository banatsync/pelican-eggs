# Iosoccer

## [Steam](https://store.steampowered.com/app/673560/IOSoccer/)


IOSoccer is a free non-commercial competitive third-person online multiplayer soccer game that offers unparalleled freedom in ball control and gameplay depth

## Server Ports

These are the servers required ports

| Port    | default |
|---------|---------|
| Game    | 27015   |

