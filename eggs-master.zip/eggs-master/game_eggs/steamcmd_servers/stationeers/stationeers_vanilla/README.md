# Stationeers

Steam Description
Construct and manage your own space station either by yourself in singleplayer or with friends online! Fully functioning atmospherics, science, power, engineering, medical, logic, and agricultural systems. Explore to find asteroids and construct elaborate factories to harvest your resources!

## SPECIAL NOTE 

The console output does not work properly with the new server. THIS IS NOT AN ERROR IN THIS EGG !!!!

## Server Ports

Stationeers requires up to 2 ports

| Port        | default |
|-------------|---------|
| Game        | 27500   |
| Steam Query | 27015   |
