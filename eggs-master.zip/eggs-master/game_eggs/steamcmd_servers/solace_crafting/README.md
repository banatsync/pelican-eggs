### Solace Crafting

Open-world fantasy survival role-playing game. Limitless distance-based difficulty with player-created fast travel, modular building and city management.

### Server Ports

| Port  | default |
|-------|---------|
| Game  | 27015   |
| Query | 27016   |
