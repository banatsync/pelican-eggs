# What is Holdfast: Nations At War

Fight on multiple fronts in Holdfast: Nations At War - A competitive multiplayer first and third person shooter set during the great Napoleonic Era. Charge into battle with over 150 players per server!

>[Holdfast: NaW](https://store.steampowered.com/app/589290/Holdfast_Nations_At_War/)

![image](https://steamcdn-a.akamaihd.net/steam/apps/589290/capsule_616x353.jpg?t=1600279941)

## Server Ports

These are the servers required ports

| Port           | default |
|----------------|---------|
| Game           | 20100   |
| Query          | 27000   |
| Communications | 8700    |
