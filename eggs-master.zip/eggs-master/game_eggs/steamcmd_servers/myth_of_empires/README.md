# Myth of Empires

## [Steam](https://store.steampowered.com/app/1371580/Myth_of_Empires/)


## Installation/System Requirements
<!--Make changes to reflect the server minimum/recommended hardware specs-->
|  | Bare Minimum | Recommended |
|---------|---------|---------|
| Processor | *AMD64 only* | *-* |
| RAM | *9 GiB* | *12 GiB* |
| Storage | *10 GiB* | *15 GiB* |
| Network | *-* | *-* |
| Game Ownership | *Not needed* | *-* |

## Server Ports

Ports required to run the server

| Port    | default |
|---------|---------|
| Game    |  11888  |
| Query   |  12888  |
| RCON    |  13888  |

