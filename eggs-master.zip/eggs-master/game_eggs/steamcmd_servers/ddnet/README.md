# DDNet

Want to play the hardest cooperative 2D platformer ever? Want to finish no map ever? Want to be in pain for hours and cry, getting nothing in return? Come play DDNet with a large community of other sufferers!

This game does not have a Anonymous Server Comp for the Server Files. To pull this you need to own the game on Steam and fill both the STEAM_USER and STEAM_PASS variables prior to installation as it packages the Server Executable into the base games files

For all added edits, these are found under **ddnet/data/autoexec_server.cfg**

## Server Port
| Port    | default |
|---------|---------|
| Game    | 8303    |

## Hardware Requirements
| Storage | RAM     | CPU |
|---------|---------|-----|
| 2.0GiB  | 250MiB  | 🥔  |
