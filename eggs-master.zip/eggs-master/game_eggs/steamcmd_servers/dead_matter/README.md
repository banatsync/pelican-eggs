# Dead

<!--Please remove these comments and irelevent parts for the server egg your adding before summiting a PR request-->

## From their [Github](https://github.com/QI-Software/deadmatterpublic)

## [Documentation]https://www.notion.so/qisoftware/Server-Setup-Guide-d17e5a3f73e34164b6a4d2b37e54da78)


## Installation/System Requirements
<!--Make changes to reflect the server minimum/recommended hardware specs-->
|  | Bare Minimum | Recommended |
|---------|---------|---------|
| Processor | *AMD64 Only 300%* | *-* |
| RAM | 18GiB* | *22GiB* |
| Storage | *8GiB* | 10GiB* |
| Network | *any* | *-* |
| Game Ownership | *Not needed* | *-* |

## Server Ports

Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 7001    |
| Query    | 7002   |

### Notes

<!--Notes about the server ports.-->
7001 is the default port, but any port can be used.
