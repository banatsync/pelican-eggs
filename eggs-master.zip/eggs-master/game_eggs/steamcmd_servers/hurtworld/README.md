# Hurtworld

## From their [website](http://hurtworld.com/)

## Install notes

Due to rate limiting the console on the panel cannot keep up with the game console and the build will complete before the panel console may show it. Reloading the console will load it to the latest part of the log.

## Server Ports

These are the servers required ports

| Port    | default |
|---------|---------|
| Game    | 12871   |
| Query   | 13871   |

### Mods/Plugins may require ports to be added to the server
