# Tower Unite

## Attention !!!!
**THIS EGG IS DEPRECATED, SINCE THEY REMOVED COMMUNITY SERVERS. ONLY OFFICIAL SERVERS ARE ALLOWED**

## desctiption
Every aspect of Tower Unite allows for online multiplayer interaction. It is a living and evolving online game world, driven by the community. Play games online with your friends, or make new friends from across the globe.

## Server Ports

Tower Unite requires a single port to be opened

| Port    | default |
|---------|---------|
| Game    | 7778    |
| Query   | 27016   |
