# The Forest

As the lone survivor of a passenger jet crash, you find yourself in a mysterious forest battling to stay alive against a society of cannibalistic mutants.
Build, explore, survive in this terrifying first-person survival horror simulator.

## NOTE

This server requires a Steam Token
You can generate the token on steam at <https://steamcommunity.com/dev/managegameservers>

## Server Ports

The forest server requires three ports for access Server port (Default), Steam port (8766), Query Port (27016) but some plugins may require extra ports to enabled for the server.

| Port   | default |
|--------|---------|
| Server | any     |
| Steam  | 8766    |
| Query  | 27016   |
