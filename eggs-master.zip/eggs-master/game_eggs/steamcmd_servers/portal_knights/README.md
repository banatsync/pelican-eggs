# Portal Knights

The world of Elysia needs YOU! Join this cooperative, 3D sandbox action RPG to level up your character, craft epic weapons, conquer enemies in real-time, and build almost anything! Craft your adventure. Forge your hero. Become the ultimate Portal Knight!

## Server

Because the server files are not in a dedicated Steam app id this egg installs the whole game and then unpacks the .zip with the dedicated server files.

**Because of this a steam account is required that own the game and has Steam guard off**

## WineHQ

The server is running with wine. So the console output can be a litte strange but it does work.

## Storage

This server will at least needs 12GB of storage allocated to be able to start

## Server Ports

Portal Knights requires 1 port

| Port  | default |
|-------|---------|
| Game  | 16365   |

