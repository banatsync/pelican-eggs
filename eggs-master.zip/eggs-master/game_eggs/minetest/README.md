# Minetest

An open source voxel game engine. Play one of our many games, mod a game to your liking, make your own game, or play on a multiplayer server.

## Stopping the server

For the server to be able to stop properly you have to give the admin/console user the permission `server` else you will have to kill the server and no date will be saved!

## Console

The console is currently bugged. It does work but the startup message is messed up.

## Rewrite
A special thank you to [Tealk](https://github.com/Tealk) for helping me rewrite this egg.