# Zandronum
Zandronum is a multiplayer oriented port, based off Skulltag, for Doom and Doom II by id Software.

This egg uses the [Freedoom](https://freedoom.github.io/) WAD by default.

### Server Ports

Zandronum requires a single port:

| Port    | default  |
|---------|----------|
| Game    | 10666    |
