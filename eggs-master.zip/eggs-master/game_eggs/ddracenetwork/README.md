# DDRaceNetwork

## From their [Website](https://ddnet.org/downloads/)

DDraceNetwork (DDNet) is an actively maintained version of DDRace, a Teeworlds modification with a unique cooperative gameplay..

## Installation/System Requirements
|  | Bare Minimum | Recommended |
|---------|---------|---------|
| Processor | Almost any proccessor will work | -|
| RAM | 100 MiB | 256 MiB |
| Storage | 70 MiB | 1024 MiB |
| Network | Any reasonable speed |- |
| Game Ownership | Not needed | The game is free, and server doesn't need the game to work. |   

## Server Ports

| Port    | default |
|---------|---------|
| Game    | 8303    |
