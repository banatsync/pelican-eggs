# Kerbal Space Program

[Dark Multiplayer](https://d-mp.org/)   
Dark Multiplayer is an up-to-date mod adding the long awaited multiplayer feature to Kerbal Space Program while including support for other mods!

## Server Ports

Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 6702    |
