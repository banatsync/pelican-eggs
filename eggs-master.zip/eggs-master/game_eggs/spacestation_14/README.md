# Spacestation 14

## From their [Site](https://spacestation14.io/)

## [Documentation](https://docs.spacestation14.io/en/getting-started/hosting)


## Minimum RAM warning

Minimum required memory to run the server.
2GB is recommended. 3GB+ is preferred

## Minimum Sorage warning

Minimum required storage to run the server.
Example: 100MiB is recommended. 2GiB+ is preferred


## Server Ports

Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 1212 (TCP+ UDP)   |

### Notes

<!--Notes about the server ports.-->
1212 is the default port, but any port can be used.

