# CS2D


## From their [Site](https://www.cs2d.com/index.php)


## [Documentation](https://www.cs2d.com/serverhosting.php)


## Install notes

This egg only supports downloading the latest releases

## Minimum RAM warning

Minimum required memory to run the server.
1GB is recommended. 2GB+ is preferred

## Minumim Sorage warning

Minimum required storage to run the server.
600Mib is recommended. 2GB+ is preferred

## Server Ports

Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 36963   |

### Notes

<!--Notes about the server ports.-->
36963 is the default port, but any port can be used.