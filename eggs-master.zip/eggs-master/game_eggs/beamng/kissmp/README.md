# BeamNG.drive - KISS Multiplayer

## From their [Github](https://github.com/TheHellBox/KISS-multiplayer)

Server settings such as the map can be changed in the `config.json` file. Port is automatically set on each boot.
