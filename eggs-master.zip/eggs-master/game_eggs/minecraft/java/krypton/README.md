# Krypton

A fast, lightweight Minecraft server written in Kotlin

[Krypton GitHub](https://github.com/KryptonMC/Krypton)

## Server Ports

Krypton only requires a single port to run, just like vanilla, though plugins may need extra ports.

## Notes

Please note that the server will not function correctly unless a pre-generated world is provided.

| Port  | default |
|-------|---------|
| Game  | 25565   |
