## Glowstone
Glowstone is an open-source replacement for CraftBukkit, Spigot, and Paper.

## Ports
Similar to CraftBukkit and it's derivatives, it only requires a single port. Other plugins may require more ports.

| Port  | default |
|-------|---------|
| Game  | 25565   |