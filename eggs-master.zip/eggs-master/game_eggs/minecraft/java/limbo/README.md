# Limbo

Standalone server program Limbo.

[Limbo Github](https://github.com/LOOHP/Limbo)

## Server Ports

The Limbo server requires a single port for access (default 25565).

| Port  | default |
|-------|---------|
| Game  | 25565   |
