# Forge Generic

## This is a generic egg for the forge standalone server

This will download the latest jar for a specific forge version.

this has a fix for the broken 1.7.10 and 1.8.9 versions forge has

## Server Ports

The minecraft server requires a single port for access (default 25565) but plugins may require extra ports to enabled for the server.

| Port  | default |
|-------|---------|
| Game  | 25565   |
