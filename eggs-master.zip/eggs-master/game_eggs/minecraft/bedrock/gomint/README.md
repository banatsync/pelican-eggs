# gomint

Easy-to-use, highly configurable Minecraft Bedrock Edition  server software with the ability to sustain in a low-resource environment.

### Server Ports

Bedrock server require a single port (default 19132)

| Port    | default  |
|---------|----------|
| Game    | 19132    |