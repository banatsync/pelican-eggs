# Minecraft Bedrock (Formerly Pocket Edition)

## [Bedrock](/game_eggs/minecraft/bedrock/bedrock)

[Minecraft Bedrock Server](https://minecraft.net/en-us/download/server/bedrock/)
The official Minecraft Bedrock (Formerly Minecraft Pocket Edition) server.

## [gomint](/game_eggs/minecraft/bedrock/gomint)

[Gomint Bedrock Server](https://github.com/gomint/gomint)
No longer actively maintained.
GoMint is a modern Minecraft Bedrock Edition server enabling you to make your visions come true

## [LiteLoaderBDS](/game_eggs/minecraft/bedrock/LiteLoader-bedrock/)

[LiteLoaderBDS](https://github.com/LiteLDev/LiteLoaderBDS)
LiteLoaderBDS is an unofficial plugin loader that provides basic API support for Bedrock Dedicated Server.

## [Nukkit](/game_eggs/minecraft/bedrock/nukkit)

[Nukkit GitHub](https://github.com/Nukkit/Nukkit)
Nukkit is a Nuclear-Powered Server Software For Minecraft: Pocket Edition

## [PowerNukkitX](/game_eggs/minecraft/bedrock/PowerNukkitX)

[PowerNukkitX](https://github.com/PowerNukkitX/PowerNukkitX)
PowerNukkitX is a software for minecraft bedrock edition in Java which is a fork of PowerNukkit

## [PocketMine MP](/game_eggs/minecraft/bedrock/pocketmine_mp)

[PocketMine MP](https://github.com/pmmp/PocketMine-MP)
A server software for Minecraft: Bedrock Edition in PHP
