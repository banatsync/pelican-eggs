# PocketMine MP
 
[PocketMine MP](https://github.com/pmmp/PocketMine-MP)   

A server software for Minecraft: Bedrock Edition in PHP  
