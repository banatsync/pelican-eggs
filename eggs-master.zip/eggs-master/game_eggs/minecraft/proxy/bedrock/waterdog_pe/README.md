# Waterdog PE

Brand new proxy server for Minecraft: Bedrock Edition

## Server Ports

| Port     | default |
|----------|---------|
| server   | 19132   |
