# Mineraft Bedrock Proxies

## Waterdog PE

[Waterdog PE](https://github.com/WaterdogPE/WaterdogPE)
WaterdogPE is a brand new Minecraft: Bedrock Edition proxy software developed by the developers of the old Waterdog Proxy.
