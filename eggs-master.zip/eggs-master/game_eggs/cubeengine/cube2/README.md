# Cube 2: Sauerbraten
[sauerbraten.org](http://sauerbraten.org/)

Cube 2: Sauerbraten is a free multiplayer & singleplayer first person shooter, the successor of the Cube FPS.
Much like the original Cube, the aim of this game is fun, old school deathmatch gameplay and also to allow map/geometry editing to be done cooperatively in-game.

## Server Ports

Ports required to run the server.

| Port    | default |
|---------|---------|
| Game    | 28785   |
| Game +1 | 28786   |

The second port is only used for the server master list to be able to update the server info. (Description, player count, etc.)

**Must be Game +1!**

### Notes

<!--Notes about the server ports.-->
28785 & 28786 is the default ports, but any port can be used.
Port 28784 must be available for pinging servers over a LAN to work.
