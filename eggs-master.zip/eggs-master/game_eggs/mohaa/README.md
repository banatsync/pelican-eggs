# Medal of Honor: Allied Assault

Medal of Honor: Allied Assault is a first-person shooter video game developed by 2015, Inc.

### Server Ports

| Port | default |
| ---- | ------- |
| Game | 12203   |

This egg uses the Unofficial MoH:AA 1.12 Patch that addes several features and security updates to allow a fair multiplayer experience.

Ones the server is installed you can check the File Manager for `Medal of Honor Reborn Patch Documentation RC3.5.1.pdf` for more information.

Check the `main/server.cfg` in the File Manager for more configuration options.
