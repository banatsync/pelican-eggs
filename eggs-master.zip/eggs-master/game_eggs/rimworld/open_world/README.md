# Open World

## From their [site](https://openworldhelp.fandom.com/wiki/Open_World_Wiki)

The Open World mod allows you to create and join servers to play with people all around the world, it introduces plenty of new features including trading, gifting, bartering, PvP and so much more!

## Server Ports

| Port    | default |
|---------|---------|
| Game    | 25555   |

### Mods/Plugins may require ports to be added to the server.  See [here](https://openworldhelp.fandom.com/wiki/Creating_a_server)  for help
