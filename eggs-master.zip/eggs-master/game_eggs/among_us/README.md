# Among Us

[BetterCrewLink Server](bettercrewlink_server)
This project implements proximity voice chat in Among Us. Everyone in an Among Us lobby with this program running will be able to communicate over voice in-game, with no third-party programs required.

[CrewLink Server](crewlink_server)
This project implements proximity voice chat in Among Us. Everyone in an Among Us lobby with this program running will be able to communicate over voice in-game, with no third-party programs required.

[Impostor Server](impostor_server)
Impostor is one of the first Among Us private servers, written in C#.
