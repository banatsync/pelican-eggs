# Minecraft Proxies

* [Java](/java/)
  * [Travertine](java/travertine)
  * [Velocity](/java/velocity)
  * [VIAaaS](/java/viaaas)
  * [Waterfall](/java/waterfall)
* [Bedrock](/bedrock)
  * [Waterdog PE](/bedrock/waterdogpe)
* [Cross Platform](/cross_platform)
  * [GeyserMC](/cross_platform/geyser)
  * [Waterdog](/cross_platform/waterdog)
