# Nukkit

[Old Nukkit GitHub](https://github.com/Nukkit/Nukkit)

## Nukkit is Abandoned, uses NukkitX now

[NukkitX](https://github.com/CloudburstMC/Nukkit)

Nukkit is a Nuclear-Powered Server Software For Minecraft: Pocket Edition
