# PowerNukkitX

[PowerNukkitX](https://github.com/PowerNukkitX/PowerNukkitX)
PowerNukkitX is a software for minecraft bedrock edition in Java which is a fork of PowerNukkit