# Purpur

Purpur is a drop-in replacement for Paper servers designed for configurability, and new fun and exciting gameplay features.

[Purpur GitHub](https://github.com/PurpurMC/Purpur)
[Purpur Website](https://purpurmc.org/)

## Server Ports

The minecraft server requires a single port for access (default 25565) but plugins may require extra ports to enabled for the server.

| Port  | default |
|-------|---------|
| Game  | 25565   |
