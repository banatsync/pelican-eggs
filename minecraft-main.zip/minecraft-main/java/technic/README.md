# Technic Eggs

[Technic](/java/technic/)

* [Attack of the B-Team](/java/technic/attack-of-the-bteam/)
* [Blightfall](/java/technic/blightfall/)
* [Hexxit](/java/technic/hexxit/)
* [Tekkit](/java/technic/Tekkit/)
* [Tekkit 2](/java/technic/Tekkit-2/)
* [Tekkit Classic](/java/technic/tekkit-classic/)
* [Tekkit Legends](/java/technic/tekkit-legends/)
* [Tekkit SMP](/java/technic/tekkit-smp/)
* [The 1.7.10 Pack](/java/technic/the-1-7-10-pack/)
* [The 1.12.2 Pack](/java/technic/the-1-12-2-pack/)
