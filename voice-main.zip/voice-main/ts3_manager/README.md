# TS3 Manager

## Author & Contributers
| Name        | Github Profile  | Buy me a Coffee |
| ------------- |-------------|-------------|
| gOOvER | https://github.com/gOOvER |[Donate](https://donate.goover.dev) |

## Description
TS3 Manager is a simple and lightwight webbased Teamspeak Webinterface

Website: https://www.ts3.app/

## Server Ports
one Port required to run the server.

| Port    | default |
|---------|---------|
| Game    | 3000    |

## Install notes

Connect with your IP from your Pteroserver and the assigned Port. Add your IP to TS Server Withlist
