# TeamSpeak ARM64

## From their [Website](https://www.teamspeak.com/)


## Server Ports

Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Voice   | 9987    |
| Query   | 10011   |
| File    | 30033   |

### arm64
* The arm64 may not perform as expected due to the amd64 to arm emulaton.