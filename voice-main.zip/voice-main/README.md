# Voice Servers

* [Teamspeak_ARM64](/teamspeak_ARM64)
* [TS3-Manager](/ts3_manager)
