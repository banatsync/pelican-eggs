# Counter-Strike

Counter-Strike is a series of multiplayer tactical first-person shooter video games in which teams of terrorists battle to perpetrate an act of terror while counter-terrorists try to prevent it. The series began on Windows in 1999 with the release of the first game, Counter-Strike.

## Counter-Strike Titles

- [Counter-Strike: Source](counter_strike_source)
- [Counter-Strike: Global-Offensive]() this egg ships with the panel
- [Counter-Strike 2](counter_strike_2)