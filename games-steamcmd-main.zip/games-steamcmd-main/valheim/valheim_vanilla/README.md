# Valheim

A brutal exploration and survival game for 1-10 players, set in a procedurally-generated purgatory inspired by viking culture. Battle, build, and conquer your way to a saga worthy of Odin’s patronage!

<https://store.steampowered.com/app/892970/Valheim/>

## Server Ports

| Port  | default |
|-------|---------|
| Game  | 2456    |
| Query | 2457    |
