# Garry's Mod egg

A copy of the one already available with the panel with the addition of the "maxplayers" setting.