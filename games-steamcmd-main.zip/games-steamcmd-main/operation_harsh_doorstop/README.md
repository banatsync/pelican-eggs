# Operation Harsh Doorstop

[Steam](https://store.steampowered.com/app/736590/Operation_Harsh_Doorstop/)

Operation: Harsh Doorstop is an Unreal Engine powered shooter sandbox similar to mod-friendly games like Ravenfield and Garry's Mod but with roots in tactical shooters like Squad and Arma III. Our game is entirely donation funded, completely free, and has full Steam workshop support! 

## Server Ports

Operation Harsh Doorstop servers require 3 ports to be open

| Port      | default |
|-----------|---------|
| Game      | 7777    |
| Query     | 27005   |
| RCON      | 7779    |