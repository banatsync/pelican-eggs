### Smalland: Survive the Wilds

Experience a big adventure on a tiny scale! Enjoy multiplayer survival in a vast, hazardous world. Preparation is key when you're this small & at the bottom of the food chain. Craft weapons & armour, tame & ride creatures, build encampments & explore a strange new land.

Steam page: [link](https://store.steampowered.com/app/768200/Smalland_Survive_the_Wilds/)

### Server Ports

| Port  | default |
|-------|---------|
| Game  | 7777   |
