# Craftopia

Craftopia is the brand new crafting game we made by combining excellent features of various existing crafting games.

## Server Ports

Craftopia requires 1 port to run.

| Port        | default |
|-------------|---------|
| Game        | 27015   |
