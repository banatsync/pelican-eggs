# Midnight Ghost Hunt

The chaotic multiplayer hide-and-seek game. Possess seemingly harmless objects as Ghosts or chase them down as Hunters before the clock strikes midnight! 

## Server Ports


| Port      | default |
|-----------|---------|
| Game      | 7777    |
| Query     | 27015   |
| Beacon    | 7787    |