# Sons of the Forest

### Game Description

Sons of the Forest is a horror survival game and sequel to The Forest by Endnight Games, Ltd.. Sent to find a missing billionaire on a remote island, you find yourself in a cannibal-infested hellscape. Craft, build, and struggle to survive, alone or with friends.

### Useful links

Steam: https://store.steampowered.com/app/1326470/Sons_Of_The_Forest/

### Author & Contributers
| Name        | Github Profile  | Buy me a Coffee |
| ------------- |-------------|-------------|
|   gOOvER   | https://github.com/gOOvER | [![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/B0B351D0Q) |


### Server Ports

Sons of the Forest requires up to 3 ports. You can choose every port you want.

| Port    | default       |
|---------|---------------|
| Game    |     8766     |
| Query     |     27016     |
| BlobSyncPort | 9700       |

## Special Note

you need a minimum of 8GB RAM for the Server to run