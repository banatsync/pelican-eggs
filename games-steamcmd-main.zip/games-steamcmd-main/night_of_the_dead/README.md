# Night of the dead

### Description
'Night of the Dead' is an open-world game that combines elements of exploration, tower defense, survival, and crafting. Traverse a world dominated by zombies while collecting various resources and powerful equipment. Build a fortress to survive the hordes of zombies that swarm every night! 


### Server Ports

| Port      | default |
|-----------|---------|
| Game      | 27015   |
| Query     | 27016   |
