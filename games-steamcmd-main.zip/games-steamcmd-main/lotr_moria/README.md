# The Lord of the Rings: Return to Moria

The only survival crafting game set in the Fourth Age of Middle-earth™. Embark on an epic journey to reclaim the Dwarven homeland of Moria, and explore, craft, and build in procedurally generated worlds. Play as a solo adventurer, or join friends in co-op gameplay for up to 8 players.

### Server Ports

| Port | Default |
|---------|---------|
| **Game** | 7777 (TCP + UDP) |


### Licence

This Egg is licensed under the AGPLv3 -> https://www.gnu.org/licenses/agpl-3.0.txt

#### Coffee

If you like my work, I would be happy to have a coffee with you:
https://donate.goover.dev/