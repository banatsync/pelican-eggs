# Fistful of Frags

## From their steamstore [Website](https://store.steampowered.com/app/265630/Fistful_of_Frags/)

Multiplayer based, first person enabled, action packed and skill demanding shooter set in the Wild West times. A unique combination of non stop action and slow but powerful weaponry.

## Server Ports

FOF servers require 1 port to be open, the SourceTV port can also be opened for spectators.

| Port      | default |
|-----------|---------|
| Game/rcon | 27015   |
| SourceTV  | 27020   |

## Steam Download [SteamStore](https://store.steampowered.com/app/265630/Fistful_of_Frags/)
