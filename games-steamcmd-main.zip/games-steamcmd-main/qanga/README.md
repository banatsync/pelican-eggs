# QANGA

[Stream](https://store.steampowered.com/app/1648190/QANGA/)

QANGA: Dive into a sci-fi adventure of exploration and resilience across the cosmos. Merge your mind with a state-of-the-art cyborg crafted by ICLab's Industry labs, and journey through this expansive universe! 

## Server Ports

QANGA requires 2 ports


| Port        | default |
|-------------|---------|
| Game        | 10000   |
| Query       | 27016   |