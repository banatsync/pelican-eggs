# Stationeers

Steam Description
Construct and manage your own space station either by yourself in singleplayer or with friends online! Fully functioning atmospherics, science, power, engineering, medical, logic, and agricultural systems. Explore to find asteroids and construct elaborate factories to harvest your resources!

## SPECIAL NOTE 

The console output does not work properly with the new server. THIS IS NOT AN ERROR IN THIS EGG !!!!

## BepInEx

BepInEx is a general purpose framework for Unity modding. BepInEx includes tools and libraries to
- load custom code (hereafter plugins) into the game on launch;
- patch in-game methods, classes and even entire assemblies without touching original game files;
- configure plugins and log game to desired outputs like console or file;
- manage plugin dependencies.

BepInEx is currently one of the most popular modding tools for Unity on GitHub.

**Notice:**
- This egg is using the latest Unix version of BepInEx available, no extra libraries added.
- This egg is also using latest version of "[StationeersMods](https://github.com/jixxed/StationeersMods)"

## Server Ports

Stationeers requires up to 2 ports

| Port        | default |
|-------------|---------|
| Game        | 27500   |
| Steam Query | 27015   |
